
#pragma once

class ExtendLibFade
{
private:

public:


};