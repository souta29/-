#include"../Title/TitleScene.h"
#include"../Object/Player/Player.h"
#include "../Object/Enemy/Enemy.h"
#include "../Object/Stage/Stage.h"

class PlayScene
{
private:
	int OldkeyState;
	int BGTex;  //�w�i�摜
	int BGMhandle; //BGM
	int CutinTex;
	int Tex;
	int m_timer;
	enum class SceneState
	{
		Main,
		RESULT,
		Fadeout,
		ChangeSceneState,
		OverID,

	};
	SceneState nowstate;

	Player player;
	Enemy enemy;
	Stage stage;

public:
	
	bool flag;


	//�ϐ��錾�I���I;;;

public:
	PlayScene();									
	~PlayScene();								
	bool GetChangeSceneFlag();     //  �V�[���]��
	void Initialize();					
	void Update();							
	void Render();							
	void Finalize();
	
	int GetWinCount() { return stage.GetWincount(); }
};
