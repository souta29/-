#include "PlayScene.h"
#include <DxLib.h>


//	�R���X�g���N�^�ƌĂ΂��֐�
PlayScene::PlayScene()
  /* :m_timer(0)
	,Tex()
	*/
{

}

PlayScene::~PlayScene()
{
}

bool PlayScene::GetChangeSceneFlag()
{
	if (nowstate == SceneState::ChangeSceneState) {

		return true;
	}
	return false;
}

void PlayScene::Initialize()
{
	BGTex= LoadGraph("Resources/Textures/�v���C�V�[��.png");
	/*Tex = LoadGraph("Resources/Textures/sozai2.png");*/
	/*m_timer = 180;*/
	nowstate = SceneState::Main;
	//player.Initialize();
	//enemy.Initialize();
	//	���������������I
	/*m_timer + GetRand(120);*/
	stage.Initialize();
}

void PlayScene::Update()
{
	stage.Update();
	/*player.Update();
	enemy.Update();*/
	/*m_timer--;*/
	switch (nowstate)
	{
	case PlayScene::SceneState::Main:

		
		if (stage.ResultChengeFlag==true||stage.ChengeCount>50)
		{
			

			nowstate = SceneState::ChangeSceneState;
		
			
		}
		if (stage.ResultChengeFlag == true&&
			
			stage.ChengeCount > 50)
		{


			nowstate = SceneState::ChangeSceneState;


		}
		


		if (stage.WinFlag == true )
		{

		if (stage.WinCount == 1)
			{

			stage.Initialize();
			}
			else if (stage.WinCount == 2)
			{
			  stage.Initialize();
			
			}
			else if (stage.WinCount == 3)
		{
			stage.Initialize();
			
		}
			else if (stage.WinCount == 4)
		{

			stage.Initialize();
			
		}
			else if (stage.WinCount == 5)
		{
			nowstate = SceneState::Fadeout;
		}

	   }
		break;
	case PlayScene::SceneState::Fadeout:
		
			nowstate = SceneState::ChangeSceneState;
		
		break;
	case PlayScene::SceneState::ChangeSceneState:
		break;
	default:
		break;
	}
}

void PlayScene::Render()
{
	/*DrawGraph(0, 0, BGTex, true);*/
	stage.Render();
	/*DrawFormatString(0,0, GetColor(255, 0, 0), "playscene");*/
	
		DrawGraph(stage.x1, 0, stage.PlayerCutin, true);
		DrawGraph(stage.x2, 440, stage.WadoCutin, true);
		if (stage.WinCount == 1)
		{
			DrawGraph(stage.x1, 0, stage.PlayerCutin, true);
			DrawGraph(stage.x2, 440, stage.TaiyaCutin, true);
	}
		if (stage.WinCount == 2)
		{
			DrawGraph(stage.x1, 0, stage.PlayerCutin, true);
			DrawGraph(stage.x2, 440, stage.Kawasaki, true);
		}
		if (stage.WinCount == 3)
		{
			DrawGraph(stage.x1, 0, stage.PlayerCutin, true);
			DrawGraph(stage.x2, 440, stage.Dedede, true);
		}
		if (stage.WinCount == 4)
		{
			DrawGraph(stage.x1, 0, stage.PlayerCutin, true);
			DrawGraph(stage.x2, 440, stage.Metanaito, true);
		}



	/*if (m_timer < 0)
	{
	}*/
	/*DrawGraph(0, 0, Tex, true);*/
	
}

void PlayScene::Finalize()
{
	
	
}


