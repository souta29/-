#include "Enemy.h"

Enemy::Enemy()
:m_pushtime(0)
 ,EnemyTex{}
 ,m_pushflag(false)
,m_attacTime(0)
,m_EnemyState{Enemy::EnemyState::STAND}
,m_EnemyType{Enemy::EnemyType::WARUDO}
{
}

Enemy::~Enemy()
{
}

void Enemy::Initialize()
{
	m_attacTime = 0;
	m_pushflag = false;
	m_EnemyState = EnemyState::STAND;
	
	switch (m_EnemyType)
	{
	case Enemy::EnemyType::WARUDO:
		m_attacTime += 40;
		EnemyTex[static_cast<int>(Enemy::EnemyState::STAND)]= LoadGraph("Resources/Textures/�ڋʒʏ헧���G.png");
		EnemyTex[static_cast<int>(Enemy::EnemyState::WIN)] = LoadGraph("Resources/Textures/�ڋʏ���.png");
		EnemyTex[static_cast<int>(Enemy::EnemyState::LOSE)] = LoadGraph("Resources/Textures/�ڋʕ���.png");
		EnemyTex[static_cast<int>(Enemy::EnemyState::DRAW)] = LoadGraph("Resources/Textures/�ڋʒʏ헧���G.png");
		break;
		/*waruStand=LoadGraph("Resources/Textures/�ڋʒʏ헧���G.png");
		waruLose = LoadGraph("Resources/Textures/�ڋʕ���.png");*/
	case Enemy::EnemyType::HOI:
		m_attacTime += 35;
		EnemyTex[static_cast<int>(Enemy::EnemyState::STAND)] = LoadGraph("Resources/Textures/�^�C�������G.png");
		EnemyTex[static_cast<int>(Enemy::EnemyState::WIN)] = LoadGraph("Resources/Textures/�^�C�������G.png");
		EnemyTex[static_cast<int>(Enemy::EnemyState::LOSE)] = LoadGraph("Resources/Textures/�^�C������.png");
		EnemyTex[static_cast<int>(Enemy::EnemyState::DRAW)] = LoadGraph("Resources/Textures/�^�C�������G.png");
		break;
	case Enemy::EnemyType::KAWASAKI:
		m_attacTime += 25;
		EnemyTex[static_cast<int>(Enemy::EnemyState::STAND)] = LoadGraph("Resources/Textures/�R�b�N�����G.png");
		EnemyTex[static_cast<int>(Enemy::EnemyState::WIN)] = LoadGraph("Resources/Textures/�R�b�N����.png");
		EnemyTex[static_cast<int>(Enemy::EnemyState::LOSE)] = LoadGraph("Resources/Textures/�R�b�N����.png");
		EnemyTex[static_cast<int>(Enemy::EnemyState::DRAW)] = LoadGraph("Resources/Textures/�R�b�N�����G.png");
		break;
	case Enemy::EnemyType::DEDEDE:
		m_attacTime += 20;
		EnemyTex[static_cast<int>(Enemy::EnemyState::STAND)] = LoadGraph("Resources/Textures/�f�f�f�����G.png");
		EnemyTex[static_cast<int>(Enemy::EnemyState::WIN)] = LoadGraph("Resources/Textures/�f�f�f����.png");
		EnemyTex[static_cast<int>(Enemy::EnemyState::LOSE)] = LoadGraph("Resources/Textures/�f�f�f����.png");
		EnemyTex[static_cast<int>(Enemy::EnemyState::DRAW)] = LoadGraph("Resources/Textures/�f�f�f�����G.png");
		break;
	case Enemy::EnemyType::METANAITO:
		m_attacTime += 15;
		EnemyTex[static_cast<int>(Enemy::EnemyState::STAND)] = LoadGraph("Resources/Textures/���^�i�C�g�����G.png");
		EnemyTex[static_cast<int>(Enemy::EnemyState::WIN)] = LoadGraph("Resources/Textures/���^�i�C�g����.png");
		EnemyTex[static_cast<int>(Enemy::EnemyState::LOSE)] = LoadGraph("Resources/Textures/���^�i�C�g����.png");
		EnemyTex[static_cast<int>(Enemy::EnemyState::DRAW)] = LoadGraph("Resources/Textures/���^�i�C�g�����G.png");
		break;
	default:
		break;
	}
}

void Enemy::Update()
{
	if (CheckHitKey(KEY_INPUT_SPACE)==1)
	{
		m_pushflag = true;
	}
	else
	{
		m_pushtime++;
	}

	m_attacTime--;
}

void Enemy::Render()
{

	

	switch (m_EnemyState)
	{
	case Enemy::EnemyState::STAND:
		DrawGraph(500, 400, EnemyTex[static_cast<int>(m_EnemyState)], true);
		break;
	case Enemy::EnemyState::WIN:
		DrawGraph(200, 400, EnemyTex[static_cast<int>(m_EnemyState)], true);
		break;
	case Enemy::EnemyState::LOSE:
		DrawGraph(200, 400, EnemyTex[static_cast<int>(m_EnemyState)], true);
		break;
	case Enemy::EnemyState::DRAW:
		DrawGraph(200, 400, EnemyTex[static_cast<int>(m_EnemyState)], true);
		break;
	}
}

	



void Enemy::Finalize()
{
}

void Enemy::SetEnemyType(Enemy::EnemyType type)
{
	m_EnemyType = type;

}

void Enemy::SetEnemyState(EnemyState state)
{
	m_EnemyState = state;
}

void Enemy::SetAttacTime(int attactime)
{
	m_attacTime += attactime;
}

int Enemy::GetTime()
{
	return m_attacTime;
}

