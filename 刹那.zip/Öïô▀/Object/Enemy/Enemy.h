#pragma once
#include <DxLib.h>
#include "../Player/Player.h"
class Enemy
{
private:

	int EnemyTex[4];

	int m_attacTime;
	bool m_pushflag;
	int m_pushtime;
	

public:
	

	enum class EnemyType
	{
		WARUDO,
		HOI,
		KAWASAKI,
		DEDEDE,
		METANAITO,
	};

	enum class EnemyState
	{
		STAND,
		WIN,
		LOSE,
		DRAW,

	};


	EnemyType m_EnemyType;

	EnemyState m_EnemyState;

	Enemy();
	~Enemy();

	void Initialize();
	void Update();
	void Render();
	void Finalize();
	void SetEnemyType(Enemy::EnemyType type);
	void SetEnemyState(EnemyState state);
	void SetAttacTime(int attactime);
	int  GetTime();
	






};