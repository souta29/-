#pragma once
#include "../Player/Player.h"
#include"../Enemy/Enemy.h"
class Stage
{
private:
	int m_timer;
	
	int BGTex;  //�w�i�摜
	int Tex;

	int Ontime;


	int NowStage;

	Player player;
	Enemy enemy; 
	



	bool m_pushflag;
	int m_pushtime;
	int m_EnemyTime;
	int m_PlayerTime;
	int StateNum;

public:
	int x1;
	int x2;
	int PlayerCutin;
	int WadoCutin;
	int TaiyaCutin;
	int Kawasaki;
	int Dedede;
	int Metanaito;

	int CutCunt;

	int Wait;

	bool FlingFlag;

	int WinCount;
	bool ResultChengeFlag;

	bool WinFlag;
	int WaitCount;

	int otetukihaikei;

	int Flyng;
	int FlyngCount;
	int FlyngCount2;

	int Sikirinaosi;

	int ChengeCount;

	int winTex;

	int wado;
	int taiya;
	int kawasaki;
	int dedede;
	int metanaito;


	Stage();
	~Stage();

	void Initialize();
	void Update();
	void Render();
	void Finalize();
	int Wincount();
	int GetWincount();

	void Reset();
};