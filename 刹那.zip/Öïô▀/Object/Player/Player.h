#pragma once
#include<DxLib.h>
#include "../../Object/Enemy/Enemy.h"
#include "../../ExtendLib/ExtendLibInput/ExtendLibInput.h"

class Player
{


public:
	
	int m_pushtime;

	int PlayerTex[4];

	
	
	bool m_pushflag;
	
	enum class PlayerState
	{
		STAND,
		WIN,
		LOSE,
		DRAW,
	};

	enum class EnemyID
	{
		WARUDO,
		HOI,
		KAWASAKI,
		DEDEDE,
		METANAITO,

	};

	EnemyID m_ID;
	

	PlayerState m_PlayerState;

	int PlayerWin;
	int Win;

	ExtendLibInput m_inputManager;
	
public:

	Player();
	~Player();

	void Initialize();
	void Update();
	void Render();
	void Finalize();
	int GetPuhsFlag();
	void SetPlayerState(PlayerState State);
	int GetTime();
	void SetEnemyID(EnemyID ID);
};